<?php
$host = "wheatley.cs.up.ac.za";
$username = "u21532941";
$password = "M4HQU6LMFIL5DYVL5GDQBZQGB357JY3Y";
$database = "u21532941_hoop";

$mysqli = new mysqli($host, $username, $password, $database);

if ($mysqli->connect_error) {
    die("Connection failure: " . $mysqli->connect_error);
} else {
}
?>
