// adding event listeners for actions performed on the manage users page
// a users details can either be updated or deleted
document.getElementById("updateBTN").addEventListener("click", function(event) {
    event.preventDefault();
    updateUsers();
});
document.getElementById("deleteBTN").addEventListener("click", function(event) {
    event.preventDefault();
    deleteUsers();
});


function updateUsers(){
    const lname = fname.get;
}
function deleteUsers(){

}